#pragma once
#import <UIKit/UIKit.h>

// Global stream mode state
extern BOOL StreamMode;
extern UIView *protectedView;

// Functions
BOOL __fn_hideCaptureForView(UIView *v, BOOL hidden);
void UpdateStreamProtectionForView(UIView *view);
void SetStreamMode(BOOL value);
