#import "PubgLoad.h"
#import <UIKit/UIKit.h>

#import "JHPP.h"
#import "ImGuiLoad.h"
#import "ImGuiDrawView.h"
#import "oxorany/oxorany.h" 

#import <unistd.h>
#import <sys/stat.h>
#import <dlfcn.h>

bool MenDeal = false;
static PubgLoad *extraInfo;
UIWindow *mainWindow;

// Helper: get first visible UIWindow via UIWindowScene (iOS 13+)
static UIWindow *GetActiveWindow() {
    for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
        if ([scene isKindOfClass:[UIWindowScene class]]) {
            UIWindowScene *ws = (UIWindowScene *)scene;
            for (UIWindow *w in ws.windows) {
                if (!w.isHidden) return w;
            }
        }
    }
    return nil;
}

@interface PubgLoad()
@property (nonatomic, strong) ImGuiDrawView *vna;
@end

@implementation PubgLoad

void kick_hacker_delayed() {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(120 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        struct stat st;
        const char* path = oxorany("/Library/MobileSubstrate/DynamicLibraries/VNTOOL.dylib");
        if (stat(path, &st) == 0) {
            if (st.st_size != 43342832) {
                exit(0);
            }
        }
        if (!MenDeal) exit(0);
    });
}

+(void)load {
    [super load];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{

        // Fix 1: syscall(26,31,...) deprecated iOS 10+ → ptrace qua dlsym
        typedef int (*ptrace_t)(int, pid_t, caddr_t, int);
        ptrace_t pt = (ptrace_t)dlsym(RTLD_DEFAULT, "ptrace");
        if (pt) pt(31, 0, 0, 0);

        // Fix 2: .keyWindow deprecated iOS 13+ → UIWindowScene
        mainWindow = GetActiveWindow();

        if (!extraInfo) {
            extraInfo = [PubgLoad new];
        }
        [extraInfo initTapGes];
        [extraInfo initTapGes2];

        MenDeal = true;
        kick_hacker_delayed();
    });
}

-(void)initTapGes {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2; tap.numberOfTouchesRequired = 3;
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView)];
}

-(void)initTapGes2 {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
    tap.numberOfTapsRequired = 2; tap.numberOfTouchesRequired = 2;
    [[JHPP currentViewController].view addGestureRecognizer:tap];
    [tap addTarget:self action:@selector(tapIconView2)];
}

// Fix 3 & 4: .windows[0] deprecated iOS 15+ → GetActiveWindow()
-(void)tapIconView2 {
    if (!self.vna) self.vna = [[ImGuiDrawView alloc] init];
    [ImGuiDrawView showChange:false];
    [GetActiveWindow().rootViewController.view addSubview:self.vna.view];
}

-(void)tapIconView {
    if (!self.vna) self.vna = [[ImGuiDrawView alloc] init];
    [ImGuiDrawView showChange:true];
    [GetActiveWindow().rootViewController.view addSubview:self.vna.view];
}
@end
